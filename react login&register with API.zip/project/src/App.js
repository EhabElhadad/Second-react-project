import React, { Component, Fragment } from "react";
import { Route, Switch } from "react-router-dom";
// import Func from "./Component/Func/Func.jsx";
import Home from "./Component/Home/Home.jsx";
import Login from "./Component/Login/Login.jsx";
import Navbar from "./Component/Navbar/Navbar.jsx";
import ProtectedRoute from "./Component/ProtectedRoute/ProtectedRoute.jsx";
import Register from "./Component/Regeister/Register.jsx";

export default class App extends Component {
  state = { isLoggedIn: false };
  isAuth = (logged) => {
    this.setState({
      isLoggedIn: logged,
    });
  };
  render() {
    return (
      <Fragment>
        <Switch>
          {/* <Route path="/home" component={Home} /> */}
          <ProtectedRoute isAuth={this.state.isLoggedIn} path="/home" component={Home} />
          <Route path="/login" render={(props)=><Login {...props} isAuth={this.isAuth}/>} />
          <Route path="/register" component={Register} />
          {/* <Route path="/func" render={(props)=><Func {...props} x="10"/>} /> */}
          <Route exact path="/" component={Navbar} />
        </Switch>
      </Fragment>
    );
  }
}
