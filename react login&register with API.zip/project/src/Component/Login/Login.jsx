
import axios from "axios";
import React, { Component, Fragment } from "react";
import Navbar from "../Navbar/Navbar";



export default class Login extends Component {

  state={errorMessage:""}
  user = {
    email: "",
    password: "",
  };

  getFormData = ({ target }) => {
    this.user[target.name] = target.value
    console.log(this.user);
  }


  sendData = async () => {
    let { data } = await axios.post("https://route-egypt-api.herokuapp.com/signin", this.user);
    console.log(data);         
    if(data.message==="success"){
      localStorage.setItem("token",data.token)
           this.props.isAuth(true)
      this.props.history.replace("/home")
    }
    else{
      console.log(data.message);
      this.setState({
        errorMessage:data.message
      }) 
    }
  }


  render() {
  
    return (
      <Fragment>
        <Navbar />
        <div className="container text-white">
          <div className="row">
            <div className="col-md-12 d-flex justify-content-center align-items-center vh-100">
              {/* <div className="d-flex justify-content-center align-items-center vh-100">
                <form className="w-50">
                  <div className="form-group">
                    <label for="exampleInputEmail1">Email address</label> */}
              <div className="w-50">
                <input
                  name="email"
                  onKeyUp={this.getFormData}
                  type="email"
                  className="form-control my-2"
                  placeholder="Enter email"
                />
                {/* <small id="emailHelp" className="form-text text-muted">
                      We will never share your email with anyone else.
                    </small>
                  </div> */}
                {/* <div className="form-group">
                    <label for="exampleInputPassword1">Password</label> */}
                <input
                  name="password"
                  onKeyUp={this.getFormData}
                  type="password"
                  className="form-control my-3"
                  placeholder="Password"
                />
                {/* </div> */}
                {/* <div className="form-check">
                    <input
                      type="checkbox"
                      className="form-check-input"
                      id="exampleCheck1"
                    />
                    <label className="form-check-label" for="exampleCheck1">
                      Check me out
                    </label>
                  </div> */}

                  {this.state.errorMessage?<div className="alert alert-danger text-center">{this.state.errorMessage}</div>:null}
                <button onClick={this.sendData} className="btn btn-primary my-3">
                  Login
                  </button>
              </div>
              {/* </form>
              </div>*/}
            </div>
          </div>
        </div>
      </Fragment>
    );
  }
}
