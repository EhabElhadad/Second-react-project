import axios from 'axios';
import React, { Component, Fragment } from 'react'
// import Navbar from '../Navbar/Navbar';
import { NavLink } from 'react-router-dom';



// export default class Home extends Component {
//     state = { allNews: [] }

//     componentDidMount() {
//         this.getNews("business")
//     }



//     async getNews(title) {
//         let { data } = await axios.get(`https://newsapi.org/v2/top-headlines?country=eg&category=${title}&apiKey=d7bc6a7929154a10b5853bf38cf6f20a`);
//         this.allNews = data.articles
//         this.setState({
//             allNews: data.articles

//         })

//     }

//     // getCountry = (e) => {
//     //     console.log(e.target.value);
//     //     this.getNews(e.target.value)
//     // }

//     getCategory = (e) => {
//         console.log(e.target.value);
//         this.getNews(e.target.value);
//     }


//     render() {
//         return (

//             <Fragment>
//                 {/* <Navbar /> */}
//                 <div className="container">
//                     <div className="row">
//                         <div className="col-md-4 py-3">
//                             <select onChange={this.getCountry} className="custom-select" name="" id="">choose country
//                             <option>choose country</option>
//                                 <option value="eg">eg</option>
//                                 <option value="sa">sa</option>
//                                 <option value="us">us</option>
//                                 <option value="ua">ua</option>
//                                 <option value="ar">ar</option>
//                             </select>
//                         </div>

//                         <div className="col-md-4 py-3">
//                             <select onChange={this.getCategory} className="custom-select" name="" id="">choose category
//                             <option>choose category</option>
//                                 <option value="general">general</option>
//                                 <option value="health">health</option>
//                                 <option value="science">science</option>
//                                 <option value="sports">sports</option>
//                                 <option value="technology">technology</option>
//                             </select>
//                         </div>
//                     </div>
//                     <div className="row">
//                         {this.state.allNews.map((value, index) => {
//                             return (<div key={index} className="col-md-4 p-3 text-white text-center">
//                                 <img src={value.urlToImage} style={{ width: "300px", height: "200px" }} />
//                                 <h1 style={{ fontSize: "20px" }}>{value.title}</h1>
//                                 <p>{value.description}</p>

//                             </div>
//                             );
//                         })}
//                     </div>
//                 </div>
//             </Fragment>
//         );
//     }
// }





export default class Home extends Component {

    logOut=()=>
    {
    localStorage.clear()
    }
    componentDidMount() {
        this.getData()
    }
    state = { users: [] }
    getData = async (e) => {
        let { data } = await axios.get("https://route-egypt-api.herokuapp.com/getAllUsers?page=22")
        console.log(data.Users);
        this.setState({
            users: data.Users
        })
    }




    render() {
        return (
            <Fragment>

                <div className="containerfluid">
                    <nav className="navbar navbar-expand-lg dark-light bg-dark">
                        <a className="navbar-brand text-primary" href="#">By Ehab Elhadad</a>
                        <h3 className="text-center text-white m-auto">......Welcome .......</h3>

                        <ul className="navbar-nav ml-auto">
                            <li className="nav-item">
                                <NavLink onClick={this.logOut} className="nav-link text-white mr-5 font-weight-bold" to="/login">Logout</NavLink>
                            </li>
                        </ul>

                    </nav>
                </div>

                <h1 className="text-white my-3 text-center">Home component</h1>
                <div className="container text-center">
                    <div className="row">
                        <table className="table table-hover table-dark my-3">
                            <thead>
                                <tr>
                                    <th scope="col">#</th>
                                    <th scope="col">First Name</th>
                                    <th scope="col">Last Name</th>
                                    <th scope="col">Email</th>
                                    <th scope="col">Age</th>
                                </tr>
                            </thead>
                            <tbody>


                                {this.state.users.map((value, index) => {
                                    return <tr key={index}>
                                        <th scope="row">{index + 1}</th>
                                        <td>{value.first_name}</td>
                                        <td>{value.last_name}</td>
                                        <td>{value.email}</td>
                                        <td>{value.age}</td>
                                    </tr>
                                })}


                            </tbody>
                        </table>
                    </div>
                </div>
            </Fragment>
        )
    }
}
