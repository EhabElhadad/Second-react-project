// import React, { useEffect, useState } from 'react'

// export default function Func(props) {
//     console.log(props);
//     let [myName,setName]=useState("Ehab Elhadad")
//     let [incCount,setIncCount]=useState(0)
//     let [decCount,setDecCount]=useState(0)

//    function changeName(){
//       setName("Salma Ehab mohamed")
//    }

//    function incraseCount(){
//     setIncCount(incCount+1)
//    }

//    function decreaseCount(){
//     setDecCount(decCount-1)
//  }

//   useEffect(()=>{
//     return ()=>  
//     console.log("bye bye");
//   })

//     return (
//         <div className="text-white">
//             <h1>Function Component</h1>
//             <h2>{myName}</h2>
//             <h2>{incCount}</h2>
//             <h2>{decCount}</h2>
//             <button onClick={changeName} className="btn btn-danger btn-sm">change name</button>
//             <button onClick={incraseCount} className="btn btn-info btn-sm">Increment</button>
//             <button onClick={decreaseCount} className="btn btn-primary btn-sm">Decrement</button>
//         </div>
//     )
// }
