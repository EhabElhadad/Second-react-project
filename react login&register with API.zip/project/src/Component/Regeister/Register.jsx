import React, { Component, Fragment } from 'react'
import Navbar from '../Navbar/Navbar'
import axios from 'axios'
import Joi, { not } from 'joi'
import { ToastContainer, toast } from 'react-toastify'
import 'react-toastify/dist/ReactToastify.css';





export default class Register extends Component {
  schema = Joi.object({
    first_name: Joi.string().alphanum().min(3).max(30).required(),
    last_name: Joi.string().alphanum().min(3).max(30),
    email: Joi.string().email({ tlds: { allow: ["com", "net"] } }),
    password: Joi.string().pattern(new RegExp("^[a-zA-Z0-9]{3,30}$")),
    age: Joi.number().integer().min(15).max(80),
  });

  state = { errors: [] };
  sendData = async () => {
    let result = this.schema.validate(this.user, { abortEarly: false });

    if (result.error) {
      const notify = () => toast.error("input reqired");
      notify();
      console.log(result.error.details);
      this.setState({
        errors: result.error.details,
      });
    } else {
      let { data } = await axios.post(
        "https://route-egypt-api.herokuapp.com/signup",
        this.user
      );
      console.log(data);
      const notify = () => toast.success("sucsess");
      notify();
    }
  };
  user = {
    first_name: "",
    last_name: "",
    email: "",
    password: "",
    age: "",
  };

  getFormData = (e) => {
    this.user[e.target.name] = e.target.value;
    console.log(this.user);
  };
  render() {
    return (
      <Fragment>
        <Navbar />
        <div className="container my-4 text-white text-center w-50">
          <ToastContainer />

          <h1>Registration Form</h1>

          <div className="form">
            <div className="input-group my-4">
              <input
                name="first_name"
                onKeyUp={this.getFormData}
                type="text"
                className="form-control"
                placeholder="First name"
                aria-label="Default"
                aria-describedby="inputGroup-sizing-default"
              />
            </div>

            {this.state.errors.find((e) => e.path[0] == "first_name") ? (
              <div className="alert alert-danger">required</div>
            ) : null}

            <div className="input-group my-4">
              <input
                name="last_name"
                onKeyUp={this.getFormData}
                type="text"
                className="form-control"
                placeholder="Last name"
                aria-label="Default"
                aria-describedby="inputGroup-sizing-default"
              />
            </div>
            {this.state.errors.find((e) => e.path[0] == "first_name") ? (
              <div className="alert alert-danger">required</div>
            ) : null}

            <div className="input-group my-4">
              <input
                name="email"
                onKeyUp={this.getFormData}
                type="email"
                className="form-control"
                placeholder="email"
                aria-label="Default"
                aria-describedby="inputGroup-sizing-default"
              />
            </div>
            {this.state.errors.find((e) => e.path[0] == "first_name") ? (
              <div className="alert alert-danger">required</div>
            ) : null}

            <div className="input-group my-4">
              <input
                name="password"
                onKeyUp={this.getFormData}
                type="password"
                className="form-control"
                placeholder="password"
                aria-label="Default"
                aria-describedby="inputGroup-sizing-default"
              />
            </div>
            {this.state.errors.find((e) => e.path[0] == "first_name") ? (
              <div className="alert alert-danger">required</div>
            ) : null}

            <div className="input-group my-4">
              <input
                name="age"
                onKeyUp={this.getFormData}
                type="agetext"
                className="form-control"
                placeholder="age"
                aria-label="Default"
                aria-describedby="inputGroup-sizing-default"
              />
            </div>
            {this.state.errors.find((e) => e.path[0] == "first_name") ? (
              <div className="alert alert-danger">required</div>
            ) : null}
          </div>
          <button onClick={this.sendData} className="btn btn-primary">
            Register
          </button>
        </div>
      </Fragment>
    );
  }
}
